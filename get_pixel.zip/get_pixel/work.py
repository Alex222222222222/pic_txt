from PIL import Image


if __name__=='__main__':
    a='!#$^*() '
    for i in range(len(a)):
        x=a[i]
        path ='get_pixel/%s/%s.png'%(x,x)
        pic=Image.open(path,'r')
        pic=pic.convert('L')
        width,height=pic.size
        s=0.000000
        for j in range(1,width):
            for k in range(1,height):
                s+=pic.getpixel((j,k))
        s/=(width*height)
        print(x+':'+str(s))
        pic.close

