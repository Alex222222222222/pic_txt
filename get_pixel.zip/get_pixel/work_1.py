import os

a='!#$^*()'
for i in range(len(a)):
    s=a[i]
    path='get_pixel/%s/%s.txt'%(s,s)
    if os.path.exists('get_pixel/%s/'%(s,))==False:
        os.makedirs('get_pixel/%s/'%(s,))
    txt=open(path,'w+')
    for j in range(99999):
        txt.write(s)
    txt.close