
import math
file=open('get_pixel/pixel.txt','r')
list_1=file.readlines()
file.close
dic={}
pixel_dic={}
for item in list_1:
    dic[math.floor(float(item[2:][:-2])+0.5)]=item[0]
j=0
k=0
for i in range(256):
    if i in dic.keys():
        k=i
        print('uehfiun')
        for x in range(j,k):
            dic[x]=dic[i]
        j=i+1
    if i==255:
        for x in range(j,256):
            dic[x]=dic[j-1]
file=open('get_pixel/pixel_2.txt','w')
for i in range(256):
    file.write('\n')
    file.write('%d:%s'%(i,dic[i]))

